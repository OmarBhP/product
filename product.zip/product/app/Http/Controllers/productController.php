<?php

namespace App\Http\Controllers;

use App\Models\name;
use App\Models\description;
use App\Models\price;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\View\View;


class ProductController extends Controller{
    public function index():View
    {
        return view('products.index',[
            'products'=>name::with('user')->latest()->get(),
        ]);
    }

    public function create(Request $createRequest):RedirectResponse
    {
        $createRequest->user()->name()->created();
        $createRequest->user()->description()->created();
        $createRequest->user()->price()->created();
        return redirect(route('products.index'));
    }

    public function store(Request $storeRequest):RedirectResponse
    {
        $storeRequest->user()->name()->created();
        $storeRequest->user()->description()->created();
        $storeRequest->user()->price()->created();
        return redirect(route('products.index'));
    }

    public function show():View
    {
        return view('products.index',[
            'products'=>name::with('user')->latest()->get(),
        ]);
    }

    public function edit(name $name,description $description,price $price):View
    {
        Gate::authorize('update',$name);
        Gate::authorize('update',$description);
        Gate::authorize('update',$price);

        return view('products.index',[
            'name'=>$name,
            'description'=>$description,
            'price'=>$price,
        ]);
    }

    public function update(Request $request,name $name,description $description,price $price):RedirectResponse
    {
        Gate::authorize('update',$name);
        Gate::authorize('update',$description);
        Gate::authorize('update',$price);

        $name->update();
        $description->update();
        $price->update();

        return redirect(route('products.index'));
    }

    public function delete(name $name,description $description,price $price):RedirectResponse
    {
        Gate::authorize('delete',$name);
        Gate::authorize('delete',$description);
        Gate::authorize('delete',$price);

        $name->delete();
        $description->delete();
        $price->delete();

        return redirect(route('products.index'));
    }
}