<form method="post" action="{{route('products.store')}}">
    <label>{{__('Product Name')}}</label>
    <input type="text">
    <br><br>
    <label>{{__('Product Description')}}</label>
    <input type="text">
    <br><br>
    <label>{{__('Product Price')}}</label>
    <input type="number">
    <br><br>
    <input type="submit" value="add product">
</form>

<form method="post" action="{{route('products.store')}}">
    <label>{{__('Product Name')}}</label>
    <input type="text">
    <br><br>
    <label>{{__('Product Description')}}</label>
    <input type="text">
    <br><br>
    <label>{{__('Product Price')}}</label>
    <input type="number">
    <br><br>
    <input type="submit" value="edit product">
</form>