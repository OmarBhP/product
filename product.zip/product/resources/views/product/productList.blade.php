@foreach ($products as $product)
<div>
    <span>{{$product->user->name}}</span>
    <span>{{$product->user->description}}</span>
    <span>{{$product->user->price}}</span>
    @if ($product->user->is(auth()->user()))
    <x-dropdown-link :href="route('products.edit', $product)">
        {{ __('Create') }}
    </x-dropdown-link>
    <x-dropdown-link :href="route('products.edit', $product)">
        {{ __('Edit') }}
    </x-dropdown-link>
    <x-dropdown-link :href="route('products.edit', $product)">
        {{ __('Delete') }}
    </x-dropdown-link>
    @endif
</div>
@endforeach